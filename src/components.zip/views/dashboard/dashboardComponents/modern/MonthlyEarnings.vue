<script setup lang="ts">
import { computed } from 'vue';

/* Chart */
const areachartOptions = computed(() => {
  
    return {
        chart: {
            type: 'area',
            height: 60,
            fontFamily: `inherit`,
            foreColor: '#a1aab2',
            toolbar: {
                show: false
            },
            sparkline: {
                enabled: true
            },
            group: 'sparklines'
        },
        colors: ['rgba(var(--v-theme-secondary))'],
        stroke: {
            curve: 'smooth',
            width: 2
        },
        fill: {
            type: 'solid',
            colors: ['rgba(var(--v-theme-secondary), 0.05)'],
            opacity: 1 // required for rgba fill to show correctly
        },
        markers: {
            size: 0
        },
        tooltip: {
            theme: 'dark',
            x: {
                show: false
            }
        }
    };
});

const areaChart = {
    series: [
        {
            name: '',
            data: [25, 66, 20, 40, 12, 58, 20]
        }
    ]
};
</script>
<template>
    <v-card elevation="10" >
        <v-card-item>
            <div class="d-flex align-center justify-space-between">
                <v-card-title class="text-headline-medium">Monthly Earnings</v-card-title>
                <v-btn size="large" icon variant="flat" color="secondary" class="rounded-circle">
                    <CurrencyDollarIcon size="22" class="text-white" />
                </v-btn>
            </div>
            <v-row>
                <v-col cols="12">
                    <div class="mt-2">
                        <h3 class="text-display-small">$6,820</h3>  
                        <div class="mt-2 d-flex gap-2 align-center">
                            <v-avatar class="bg-lighterror text-accent" size="25">
                                <ArrowDownRightIcon size="20" />
                            </v-avatar>
                            <span class="text-title-large font-weight-bold">+9%</span>
                            <span class="text-title-large textSecondary ">last year</span>
                        </div>
                    </div>
                </v-col>
            </v-row>
        </v-card-item>
        <div class="mt-3 ">
            <apexchart type="area" height="60" :options="areachartOptions" :series="areaChart.series"> </apexchart>
        </div>
    </v-card>
</template>
