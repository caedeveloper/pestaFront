<script setup lang="ts">
import { computed } from 'vue';

/* Chart */
const chartOptions = computed(() => {
    return {
        labels: ['Profit', 'Revenue', 'Expance'],
        chart: {
            height: 275,
            type: 'donut',
            foreColor: '#adb0bb',
            fontFamily: `inherit`,
            toolbar: {
                show: false
            }
        },
        colors: ['rgba(var(--v-theme-primary))', 'rgba(var(--v-theme-lightprimary))', 'rgba(var(--v-theme-secondary))'],
        plotOptions: {
            pie: {
                donut: {
                    size: '89%',
                    background: 'transparent',

                    labels: {
                        show: true,
                        name: {
                            show: true,
                            offsetY: 7
                        },
                        value: {
                            show: false
                        },
                        total: {
                            show: true,
                            fontSize: '20px',
                            fontWeight: '600',
                            label: '$500,458'
                        }
                    }
                }
            }
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            show: false
        },
        legend: {
            show: false
        },
        tooltip: {
            theme: 'dark',
            fillSeriesColor: false,
            x: {
                format: 'dd/MM/yy HH:mm'
            }
        }
    };
});
const seriescolumnchart = [55, 55, 55];
</script>
<template>
    <v-card elevation="10" class="h-100">
        <v-card-item >
            <v-card-title class="text-headline-medium">Sales Overview</v-card-title>
            <v-card-subtitle class="text-title-large textSecondary">Every month</v-card-subtitle>
            <div class="mt-auto">
                <apexchart class="mt-6" type="donut" height="250" :options="chartOptions" :series="seriescolumnchart"> </apexchart>
                <v-row class="mt-5">
                    <v-col cols="6">
                        <div class="d-flex align-center mt-md-6 mt-3">
                            <v-avatar class="rounded-md bg-lightprimary text-primary">
                                <GridDotsIcon size="22" />
                            </v-avatar>
                            <div class="pl-4">
                                <h3 class="text-headline-small">$23,450</h3>
                                <h6 class="text-title-large textSecondary">Profit</h6>
                            </div>
                        </div>
                    </v-col>
                    <v-col cols="6" class="d-flex justify-lg-start justify-end">
                        <div class="d-flex align-center mt-md-6 mt-3">
                            <v-avatar class="rounded-md bg-lightsecondary text-secondary">
                                <GridDotsIcon size="22" />
                            </v-avatar>
                            <div class="pl-4">
                                <h3 class="text-headline-small">$23,450</h3>
                                <h6 class="text-title-large textSecondary">Expance</h6>
                            </div>
                        </div>
                    </v-col>
                </v-row>
            </div>
        </v-card-item>
    </v-card>
</template>
