<template>
    <v-expansion-panels variant="popout">
        <v-expansion-panel elevation="10">
            <v-expansion-panel-title class="text-headline-small">Accordion 1</v-expansion-panel-title>
            <v-expansion-panel-text> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse malesuada lacus ex, sit amet blandit leo lobortis eget.</v-expansion-panel-text>
            <v-divider></v-divider>
        </v-expansion-panel>
        <v-expansion-panel elevation="10">
            <v-expansion-panel-title class="text-headline-small">Accordion 2</v-expansion-panel-title>
            <v-expansion-panel-text> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse malesuada lacus ex, sit amet blandit leo lobortis eget.</v-expansion-panel-text>
            <v-divider></v-divider>
        </v-expansion-panel>
        <v-expansion-panel elevation="10" >
            <v-expansion-panel-title  class="text-headline-small">Accordion 3</v-expansion-panel-title>
            <v-expansion-panel-text> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse malesuada lacus ex, sit amet blandit leo lobortis eget.</v-expansion-panel-text>
            <v-divider></v-divider>
        </v-expansion-panel>
    </v-expansion-panels>
</template>
