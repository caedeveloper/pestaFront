<template>
    <v-alert type="error" variant="tonal" class="mb-4">
        <h5 class="text-headline-small text-capitalize">error</h5>
        <div>This is an error alert — check it out!</div>
    </v-alert>
    <v-alert type="warning" variant="tonal" class="mb-4">
        <h5 class="text-headline-small text-capitalize">warning</h5>
        <div>This is an warning alert — check it out!</div>
    </v-alert>
    <v-alert type="info" variant="tonal" class="mb-4">
        <h5 class="text-headline-small text-capitalize">info</h5>
        <div>This is an info alert — check it out!</div>
    </v-alert>
    <v-alert type="success" variant="tonal" class="mb-4">
        <h5 class="text-headline-small text-capitalize">success</h5>
        <div>This is an success alert — check it out!</div>
    </v-alert>
</template>
